---
title: Todo
icon: "fa-square-check"
order: 2
---

- Dark Mode for Navigation
- Navigation for Mobile, and other Small Device
- ~~Last Update Date & Time to automattically update over every deploy with a Commit and Diff showing what has beed added~~
- Move Image from imbgg to appwrite
