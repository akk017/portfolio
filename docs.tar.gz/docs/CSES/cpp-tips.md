---
title: CPP Tips and Tricks
icon: fa-circle-up
slug: cpp-tips
sources:[Code Forces#1](https://codeforces.com/blog/entry/15643)
sources:[Code Forces#2](https://codeforces.com/blog/entry/15547)
sources:[Code Forces#3](https://codeforces.com/blog/entry/74684)
sources:[Code Forces#4](https://codeforces.com/blog/entry/925)
sources:[Code Forces#5](https://codeforces.com/blog/entry/112926)
---


In `myprettyprint.hpp`, Support Only Upto 5 Args

```cpp
#ifndef ONLINE_JUDGE
    #include "myprettyprint.hpp"

    template <typename T>
    using mat = vector<vector<T>>;

    template <typename T>
    void show_mat_graph(mat<T> graph){
        for(auto vec: graph){
            for(auto k: vec){
                cout << k << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
#else
    #define print(...)
    void show_mat_graph(...)
#endif
```

<div class="divider"></div>

```cpp
template <class T1, class T2>
ostream &operator<<(ostream &os, const pair<T1, T2> &p) {
  return os << '{' << p.first << ", " << p.second << '}';
}

template <class T, class = decay_t<decltype(*begin(declval<T>()))>,
          class = enable_if_t<!is_same<T, string>::value>>
ostream &operator<<(ostream &os, const T &c) {
  os << '[';
  for (auto it = c.begin(); it != c.end(); ++it)
    os << &", "[2 * (it == c.begin())] << *it;
  return os << ']';
}
//support up to 5 args
#define _NTH_ARG(_1, _2, _3, _4, _5, _6, N, ...) N
#define _FE_0(_CALL, ...)
#define _FE_1(_CALL, x) _CALL(x)
#define _FE_2(_CALL, x, ...) _CALL(x) _FE_1(_CALL, __VA_ARGS__)
#define _FE_3(_CALL, x, ...) _CALL(x) _FE_2(_CALL, __VA_ARGS__)
#define _FE_4(_CALL, x, ...) _CALL(x) _FE_3(_CALL, __VA_ARGS__)
#define _FE_5(_CALL, x, ...) _CALL(x) _FE_4(_CALL, __VA_ARGS__)
#define FOR_EACH_MACRO(MACRO, ...)                                             \
  _NTH_ARG(dummy, ##__VA_ARGS__, _FE_5, _FE_4, _FE_3, _FE_2, _FE_1, _FE_0)     \
  (MACRO, ##__VA_ARGS__)
//Change output format here
#define out(x) #x " = " << x << "; "
#define print(...)                                                              \
  cerr << "Line " << __LINE__ << ": " FOR_EACH_MACRO(out, __VA_ARGS__) << "\n"
```

